/**Programming Problems*/
/**
You have an array of n characters or integers. Write a function to return the k most frequently
occurring elements. For your answer, we will need the function codes, output based on the
following input and a short description of what you are trying to achieve.
    Input: array = [4, 3, 2, 4, 3, 4], k = 2 
 */
 const kMostFrequentlyOccurElements = (input, k) => {
    let countMap = new Map();
    input.forEach(element => {
        if(countMap.has(element)) {
            let count = countMap.get(element) + 1;
            countMap.set(element, count);
        } else {
            countMap.set(element, 1);
        }
    });

    let resultArray = [];
    countMap.forEach((value, key) => {
        if(value === k) {
            resultArray.push(key);
        }
    });

    return resultArray;
};

/**
 1. Map has been created to store count of each elements in the array as key, value e.g Element => Count
 2. First time element entered into a count value 1. Subsequently element count get increased by one whenever element found in input array.
 3. Map iterated to get all elements having count equal to k and results are stored and returned in "resultArray" 
 
 e.g kMostFrequentlyOccurElements([4, 3, 2, 4, 3, 4], 2) => [3]
     kMostFrequentlyOccurElements([6, 1, 2, 1, 3, 6, 5, 6, 1], 3) => [6, 1]
 */

/**------------------------------------------------------------------------------------------------------------------------------------*/
/**
You have an array of n integers and an integer t. Write a function to return the indices of the
two numbers in the array which add up to t. You cannot use the same number twice. For your
answer, we will need the function codes, output based on the following input and a short
description of what you are trying to achieve.
    Input: array = [11, 2, 7, 15], t = 9
*/
const getIndices = (input, sum) => {
    let combinationLength = 2, elementArray = [];

    let generateCombinations = function(previousResult, tempInput) {
        for (var i = 0; i < tempInput.length; i++) {
            let tempChunk = [...previousResult, tempInput[i]];
            
            if(tempChunk.length ===  combinationLength && 
                tempChunk.length === new Set(tempChunk).size &&
                sum === tempChunk.reduce((a, b) => a+b, 0)) {
                    elementArray.push(tempChunk);
                }

            generateCombinations([...previousResult, tempInput[i]], tempInput.slice(i + 1));
      }
    };

    let findIndex = dataArray => {
        let result = [];
        dataArray.forEach(item => result.push(input.indexOf(item)));
        return result.sort();
    };

    generateCombinations([], input);
    
    let indexResult = [], resultSet = new Set();
    elementArray.forEach(item => {
        let result = findIndex(item);
        if(!resultSet.has(result.join())) {
            resultSet.add(result.join());
            indexResult.push(result);
        }
    });

    return indexResult;
};
/**
 1. Combination of 2 elements generated from the given array with checking of same number occuring twice. 
 2. Two elements of each chunck added and result equals to "sum" pushed into an array 
 3. Duplicates removed using Set and pushed to indexResult which contains required result result 
 e.g getIndices([11, 2, 7, 15], 9) => [[1, 2]]
     getIndices([1, 7, 2, 6, 5, 3], 8) => [[0, 1], [2, 3], [4, 5]]
 */
