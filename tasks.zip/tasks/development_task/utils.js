exports.isIP = ip => {
    if (typeof(ip) !== 'string' || !ip.match(/\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}/))
      return false;
      
    return ip.split('.').filter(octect => octect >= 0 && octect <= 255).length === 4;
  }