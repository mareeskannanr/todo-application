exports.restrictionMap = new Map();

exports.requestMap = new Map();
