const config = require('./config');

module.exports = function(req, res, next) {
    let ipAddress = req.ip;

    //Removing subnet prefix
    ipAddress = ipAddress.replace("::ffff:", '');

    //IP don't have restriction free to use api's
    if(!config.restrictionMap.has(ipAddress)) {
        
        if(config.requestMap.has(ipAddress)) {
            let ipRequestsInfo = config.requestMap.get(ipAddress);
            ipRequestsInfo.allowed.push({
                url: req.url,
                date: new Date()
            });
            
            config.requestMap.set(ipAddress, ipRequestsInfo);
        } else {
            let data = {
                count: 0,
                time: new Date().getTime(),
                allowed: [{
                    url: req.url,
                    date: new Date()
                }],
                denied: []
            };
    
            config.requestMap.set(ipAddress, data);    
        }
        
        return next();
    }

    let ipRestrictionInfo = config.restrictionMap.get(ipAddress);
    //log first request from this ip to request map
    if(!config.requestMap.has(ipAddress)) {
        let data = {
            count: 1,
            time: new Date().getTime(),
            allowed: [{
                url: req.url,
                date: new Date()
            }],
            denied: []
        };

        config.requestMap.set(ipAddress, data);
        return next();
    }

    //Resetting Request Count after restriction interval expires
    let ipRequestsInfo = config.requestMap.get(ipAddress);
    if(new Date().getTime() - ipRequestsInfo.time > ipRestrictionInfo.interval * 60 * 1000) {
        ipRequestsInfo.count = 1;
        ipRequestsInfo.time = new Date().getTime();
        ipRequestsInfo.allowed.push({
            url: req.url,
            date: new Date()
        });

        config.requestMap.set(ipAddress, ipRequestsInfo);
        return next();
    }

    //check limit based on it allow or deny request from this IP Address 
    if(ipRequestsInfo.count < ipRestrictionInfo.limit) {
        ipRequestsInfo.count += 1;

        ipRequestsInfo.allowed.push({
            url: req.url,
            time: new Date()
        });

        config.requestMap.set(ipAddress, ipRequestsInfo);
        return next();
    }
    
    
    ipRequestsInfo.denied.push({
        url: req.url,
        time: new Date()
    });

    config.requestMap.set(ipAddress, ipRequestsInfo);
    return res.status(403).json({
        message: "Request Limit exceeds for this IP"
    });

};