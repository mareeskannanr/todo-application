const express = require("express");
const app = express();
const logger = require('morgan'); 
const PORT = 3000 || process.env.PORT;

const middleware = require('./middleware');
const routes = require('./routes');

app.use(logger('dev'));
app.use(middleware);

app.use(express.json());
app.use(express.urlencoded({
    extended: true
}));

app.enable('trust proxy', true);

app.get('/', (req, res) => res.send(`Application running successfully`));

app.use('/api', routes);

app.listen(PORT, () => console.log(`Application is running on port ${PORT}`));