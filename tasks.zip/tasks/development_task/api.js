const config = require('./config');
const utils = require('./utils');

exports.limitSetting = (req, res, next) => {
    let errorArray = [];

    if(req.body.hasOwnProperty('ipAddress')) {
        if(!utils.isIP(req.body.ipAddress)) {
            errorArray.push('ipAddress is invalid.');    
        }
    } else {
        errorArray.push('ipAddress is required.');
    }

    if(req.body.hasOwnProperty('intervalInMinutes')) {
        if(!req.body.intervalInMinutes || isNaN(req.body.intervalInMinutes)) {
            errorArray.push('intervalInMinutes is invalid.');    
        }
    } else {
        errorArray.push('intervalInMinutes is required.');
    }

    if(req.body.hasOwnProperty('limit')) {
        if(!req.body.limit || isNaN(req.body.limit)) {
            errorArray.push('limit is invalid.');    
        } else if(req.body.limit < 1) {
            errorArray.push('limit must be greater than zero.');
        }
    } else {
        errorArray.push('limit is required.');
    }

    if(errorArray.length > 0) {
        return res.status(400).json({
            error: errorArray
        });
    }

    if(config.restrictionMap.has(req.body.ipAddress) && !req.body.reset) {
        return res.status(400).json({
            message: 'Restriction already exists for this IP Address. To reset make reset flag true in your request!'
        });
    }

    config.restrictionMap.set(req.body.ipAddress, {
        interval: req.body.intervalInMinutes,
        limit: req.body.limit
    });

    res.json({
        message: "Request Limit Setting done!"
    });
};

exports.getDate = (req, res) => {
    res.status(200).json({
        date: new Date(),
        url: req.url
    });
};

exports.getRequestList = (req, res) => {

    let result = {};
    if(req.query.ip) {
        if(config.requestMap.has(req.query.ip)) {
            result = {[req.query.ip] : {...config.requestMap.get(req.query.ip)}};
        } else {
            return res.status(404).json({
                message: 'Data Not Exists for your request!'
            });
        }
        
    } else {
        config.requestMap.forEach((value, key) => result[key] = {...value});
    }

    for(let prop in result) {
        delete result[prop].count;
        delete result[prop].time;
        if(req.query.type === 'allowed') { delete result[prop].denied; }
        if(req.query.type === 'denied') { delete result[prop].allowed; }
    }

    res.status(200).json(result);
};
