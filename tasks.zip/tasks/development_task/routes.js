const router = require('express').Router();
const api = require('./api');

router.route('/limit').post(api.limitSetting);

router.route('/show').get(api.getRequestList);

router.route('/:endpoint').get(api.getDate);

module.exports = router;